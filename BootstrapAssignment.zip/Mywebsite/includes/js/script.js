/*

My Custom JS
============

Author:  Brad Hussey
Updated: August 2013
Notes:	 Hand coded for Udemy.com

*/
$(function() {
	
	$('#alertAbove').click(function(e) {
		
		e.preventDefault();
		
		$('#success').slideDown();
		
	});
	
	
	
});